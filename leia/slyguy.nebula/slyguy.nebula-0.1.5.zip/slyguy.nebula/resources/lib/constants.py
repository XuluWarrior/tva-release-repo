HEADERS = {
    'user-agent': 'Dalvik/2.1.0 (Zype Android; Linux; U; Android 5.0.2; One X Build/LRX22G)',
}